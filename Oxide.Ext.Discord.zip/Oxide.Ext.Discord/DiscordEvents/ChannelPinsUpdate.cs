﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class ChannelPinsUpdate
    {
        public string channel_id { get; set; }
        public string last_pin_timestamp { get; set; }
    }
}
