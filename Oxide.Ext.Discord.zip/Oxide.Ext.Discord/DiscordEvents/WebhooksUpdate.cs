﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class WebhooksUpdate
    {
        public string guild_id { get; set; }
        public string channel_id { get; set; }
    }
}
