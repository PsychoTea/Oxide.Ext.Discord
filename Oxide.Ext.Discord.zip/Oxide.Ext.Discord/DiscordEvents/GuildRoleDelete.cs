﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class GuildRoleDelete
    {
        public string guild_id { get; set; }
        public string role_id { get; set; }
    }
}
