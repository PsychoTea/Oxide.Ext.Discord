﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class MessageReactionRemoveAll
    {
        public string channel_id { get; set; }
        public string message_id { get; set; }
    }
}
