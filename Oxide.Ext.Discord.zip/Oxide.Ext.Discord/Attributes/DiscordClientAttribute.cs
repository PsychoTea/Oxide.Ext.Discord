﻿using System;

namespace Oxide.Ext.Discord.Attributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class DiscordClientAttribute : Attribute { }
}
