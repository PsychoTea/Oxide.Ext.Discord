﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class GuildEmbed
    {
        public bool enabled { get; set; }
        public string channel_id { get; set; }
    }
}
