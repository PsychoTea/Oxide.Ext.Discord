﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class Account
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
