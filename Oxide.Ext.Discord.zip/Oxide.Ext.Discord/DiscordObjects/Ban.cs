﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class Ban
    {
        public string reason { get; set; }
        public User user { get; set; }
    }
}
