﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class OptionalAuditEntryInfo
    {
        public string delete_member_days { get; set; }
        public string members_removed { get; set; }
        public string channel_id { get; set; }
        public string count { get; set; }
        public string id { get; set; }
        public string type { get; set; }
        public string role_name { get; set; }
    }
}
