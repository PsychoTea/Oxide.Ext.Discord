﻿namespace Oxide.Ext.Discord.RESTObjects
{
    public class ObjectPosition
    {
        public string id { get; set; }
        public int position { get; set; }
    }
}
