﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class Game
    {
        public string name { get; set; }
        public int? type { get; set; }
        public string url { get; set; }
    }
}
