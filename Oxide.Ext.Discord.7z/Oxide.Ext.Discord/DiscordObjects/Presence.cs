﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class Presence
    {
        public User user { get; set; }
        public string status { get; set; }
        public Game game { get; set; }
    }
}
