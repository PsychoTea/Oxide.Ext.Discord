﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    public class Overwrite
    {
        public string id { get; set; }
        public string type { get; set; }
        public int? allow { get; set; }
        public int? deny { get; set; }
    }
}
