﻿namespace Oxide.Ext.Discord
{
    public class DiscordSettings
    {
        public string ApiToken { get; set; }
    }
}