﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class VoiceServerUpdate
    {
        public string token { get; set; }
        public string guild_id { get; set; }
        public string endpoint { get; set; }
    }
}
