﻿namespace Oxide.Ext.Discord.DiscordEvents
{
    public class GuildIntergrationsUpdate
    {
        public string guild_id { get; set; }
    }
}
