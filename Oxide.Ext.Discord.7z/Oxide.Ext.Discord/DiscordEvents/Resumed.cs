﻿using System.Collections.Generic;

namespace Oxide.Ext.Discord.DiscordEvents
{
    public class Resumed
    {
        public List<string> _trace { get; set; }
    }
}
