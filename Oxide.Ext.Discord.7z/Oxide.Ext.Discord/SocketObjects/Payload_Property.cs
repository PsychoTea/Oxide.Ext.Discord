﻿namespace Oxide.Ext.Discord.DiscordObjects
{
    class Payload_Property
    {
        public string os { get; set; }
        public string browser { get; set; }
        public string referrer { get; set; }
        public string device { get; set; }
        public string referring_domain { get; set; }
    }
}
